<div class="content mt-3">
			<div class="card bg-secondary bg-secondary">
				<div class="card-body">
					<a href="index.php" class="btn text-light">Dashboard</a>
					<a href="peminjaman.php" class="btn text-light">Peminjaman</a>
					<a href="ulasan.php" class="btn text-light">Ulasan Buku</a>
					<a href="../logout.php" class="btn text-light">Logout</a>
				</div>
			</div>
</div>